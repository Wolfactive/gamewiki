<div class="breadcrumbs">
  <div class="breadcrumbs__contain container">
      <?php if ( function_exists('yoast_breadcrumb') ) {yoast_breadcrumb('<p id="breadcrumbs" class="f-breadcrumbs">','</p>');} ?>
  </div>
</div>
