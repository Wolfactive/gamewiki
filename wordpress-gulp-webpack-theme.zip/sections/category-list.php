<div class="categoryList">
  <div class="categoryList__contain">
    <?php get_term_list('category') ?>
  </div>
</div>
