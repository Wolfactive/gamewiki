<div class="menuRanking">
  <div class="menuRanking__contain">   
    <div class="menuRanking__content">
      <?php get_template_part('sections/app-ranking') ?>
    </div>
  </div>
</div>
